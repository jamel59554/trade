import { Asset, MarketEvent, SimulationSettings } from '../types/market';
import { generateMarketEvent } from './marketGenerator';

// Frequency in ms for price updates based on timeframe
const UPDATE_FREQUENCIES = {
  '1m': 500,   // 500ms for 1-minute timeframe
  '5m': 1000,  // 1s for 5-minute timeframe
  '15m': 1500, // 1.5s for 15-minute timeframe
  '30m': 2000, // 2s for 30-minute timeframe
  '1h': 3000,  // 3s for 1-hour timeframe
  '4h': 4000,  // 4s for 4-hour timeframe
  '1d': 5000   // 5s for 1-day timeframe
};

// Simulator class to handle price updates and market events
export class SimulationEngine {
  private assets: Asset[];
  private settings: SimulationSettings;
  private activeEvents: MarketEvent[] = [];
  private updateInterval: number | null = null;
  private eventInterval: number | null = null;
  private timeframe: string = '15m';
  private onPriceUpdate: (assetId: string, newPrice: number) => void;
  private onEventGenerated: (event: MarketEvent) => void;
  
  constructor(
    assets: Asset[],
    settings: SimulationSettings,
    timeframe: string,
    onPriceUpdate: (assetId: string, newPrice: number) => void,
    onEventGenerated: (event: MarketEvent) => void
  ) {
    this.assets = assets;
    this.settings = settings;
    this.timeframe = timeframe;
    this.onPriceUpdate = onPriceUpdate;
    this.onEventGenerated = onEventGenerated;
  }
  
  // Start the simulation
  public start(): void {
    if (this.updateInterval !== null) return;
    
    // Start price updates based on timeframe
    const updateFrequency = UPDATE_FREQUENCIES[this.timeframe as keyof typeof UPDATE_FREQUENCIES] || 1500;
    this.updateInterval = window.setInterval(() => this.updatePrices(), updateFrequency);
    
    // Start event generation
    const eventFrequency = Math.floor(3600000 / this.settings.eventFrequency); // Convert events per hour to ms
    this.eventInterval = window.setInterval(() => this.generateEvent(), eventFrequency);
  }
  
  // Pause the simulation
  public pause(): void {
    if (this.updateInterval !== null) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
    
    if (this.eventInterval !== null) {
      clearInterval(this.eventInterval);
      this.eventInterval = null;
    }
  }
  
  // Change the timeframe
  public setTimeframe(timeframe: string): void {
    this.timeframe = timeframe;
    
    // Restart with new frequency if running
    if (this.updateInterval !== null) {
      this.pause();
      this.start();
    }
  }
  
  // Update settings
  public updateSettings(settings: SimulationSettings): void {
    this.settings = settings;
    
    // Restart with new settings if running
    if (this.updateInterval !== null) {
      this.pause();
      this.start();
    }
  }
  
  // Update assets data
  public updateAssets(assets: Asset[]): void {
    this.assets = assets;
  }
  
  // Clean up
  public destroy(): void {
    this.pause();
  }
  
  // Private methods
  
  private updatePrices(): void {
    // Update each asset price
    this.assets.forEach(asset => {
      const newPrice = this.calculateNextPrice(asset);
      this.onPriceUpdate(asset.id, newPrice);
    });
    
    // Process and expire active events
    this.processActiveEvents();
  }
  
  private processActiveEvents(): void {
    const now = Date.now();
    const newActiveEvents = this.activeEvents.filter(event => {
      return (event.timestamp + (event.impactDuration * 1000)) > now;
    });
    
    this.activeEvents = newActiveEvents;
  }
  
  private calculateNextPrice(asset: Asset): number {
    // Base random walk model
    const baseVolatility = asset.volatility / 100; // Convert percentage to decimal
    let volatilityMultiplier = this.settings.volatilityMultiplier;
    let trendBias = 0;
    
    // Apply active events effects
    this.activeEvents.forEach(event => {
      // Check if this asset is affected
      if (event.affectedAssets.includes(asset.id)) {
        // Apply effects based on event type
        if (event.impactType === 'volatility' || event.impactType === 'both') {
          volatilityMultiplier += event.severity * 0.5;
        }
        
        if (event.impactType === 'trend' || event.impactType === 'both') {
          const directionMultiplier = 
            event.impactDirection === 'positive' ? 1 : 
            event.impactDirection === 'negative' ? -1 :
            Math.random() > 0.5 ? 1 : -1; // Mixed direction
            
          trendBias += (directionMultiplier * event.severity * 0.003);
        }
      }
    });
    
    // Calculate random price movement
    const volatility = baseVolatility * volatilityMultiplier;
    const randomChange = (Math.random() * 2 - 1) * volatility;
    const trendChange = trendBias;
    const percentChange = randomChange + trendChange;
    
    // Apply price change
    return asset.price * (1 + percentChange);
  }
  
  private generateEvent(): void {
    // Generate market event
    const newEvent = generateMarketEvent(this.assets, {
      enableCrises: this.settings.enableCrises,
      enableFlashCrashes: this.settings.enableFlashCrashes,
      difficultyLevel: this.settings.difficultyLevel
    });
    
    // Add to active events
    this.activeEvents.push(newEvent);
    
    // Notify subscribers
    this.onEventGenerated(newEvent);
  }
}