import { Asset, AssetClass, HistoricalPrice, MarketEvent } from '../types/market';

// Sample data for generating realistic assets
const STOCK_SYMBOLS = ['AAPL', 'MSFT', 'AMZN', 'GOOGL', 'META', 'TSLA', 'NVDA', 'JPM', 'V', 'JNJ'];
const FOREX_SYMBOLS = ['EUR/USD', 'USD/JPY', 'GBP/USD', 'USD/CHF', 'AUD/USD', 'USD/CAD', 'NZD/USD'];
const CRYPTO_SYMBOLS = ['BTC/USD', 'ETH/USD', 'XRP/USD', 'SOL/USD', 'DOGE/USD', 'ADA/USD', 'DOT/USD'];

const STOCK_NAMES = [
  'Apple Inc.',
  'Microsoft Corp',
  'Amazon.com Inc',
  'Alphabet Inc',
  'Meta Platforms Inc',
  'Tesla Inc',
  'NVIDIA Corp',
  'JPMorgan Chase & Co',
  'Visa Inc',
  'Johnson & Johnson'
];

// Generate random price within a reasonable range for the asset class
const generateBasePrice = (assetClass: AssetClass): number => {
  switch (assetClass) {
    case 'stock':
      return 10 + Math.random() * 990; // $10-$1000
    case 'forex':
      return 0.5 + Math.random() * 1.5; // 0.5-2.0
    case 'crypto':
      if (Math.random() > 0.7) {
        return 1000 + Math.random() * 49000; // High value crypto $1000-$50000
      } else {
        return 0.1 + Math.random() * 999.9; // Lower value crypto $0.10-$1000
      }
  }
};

// Generate realistic historical price data
const generateHistoricalPrices = (basePrice: number, volatility: number): HistoricalPrice[] => {
  const prices: HistoricalPrice[] = [];
  const now = Date.now();
  const dayInMs = 24 * 60 * 60 * 1000;
  
  // Generate 30 days of historical daily data
  for (let i = 30; i >= 0; i--) {
    const timestamp = now - (i * dayInMs);
    let price = basePrice;
    
    // Adjust price with some random walk
    if (i !== 30) {
      const previousClose = prices[prices.length - 1].close;
      const change = previousClose * volatility * (Math.random() * 2 - 1) * 0.05; // Max 5% change
      price = previousClose + change;
    }
    
    // Generate OHLC data
    const dailyVolatility = volatility * 0.01; // Smaller intraday moves
    const high = price * (1 + Math.random() * dailyVolatility);
    const low = price * (1 - Math.random() * dailyVolatility);
    const open = low + Math.random() * (high - low);
    const close = low + Math.random() * (high - low);
    const volume = Math.floor(100000 + Math.random() * 9900000); // 100K - 10M
    
    prices.push({
      timestamp,
      open,
      high,
      low,
      close,
      volume
    });
  }
  
  return prices;
};

// Generate a set of initial assets for the simulator
export const generateInitialAssets = (): Asset[] => {
  const assets: Asset[] = [];
  
  // Generate stocks
  STOCK_SYMBOLS.forEach((symbol, index) => {
    const volatility = 0.5 + Math.random() * 2; // 0.5% - 2.5%
    const basePrice = generateBasePrice('stock');
    const historicalPrices = generateHistoricalPrices(basePrice, volatility);
    const latestPrice = historicalPrices[historicalPrices.length - 1].close;
    const previousPrice = historicalPrices[historicalPrices.length - 2].close;
    
    assets.push({
      id: `stock_${index}`,
      symbol,
      name: STOCK_NAMES[index],
      assetClass: 'stock',
      price: latestPrice,
      previousPrice,
      dailyChange: latestPrice - previousPrice,
      dailyChangePercent: ((latestPrice - previousPrice) / previousPrice) * 100,
      volatility,
      volume: Math.floor(100000 + Math.random() * 9900000), // 100K - 10M
      historicalPrices
    });
  });
  
  // Generate forex pairs
  FOREX_SYMBOLS.forEach((symbol, index) => {
    const volatility = 0.2 + Math.random() * 0.8; // 0.2% - 1%
    const basePrice = generateBasePrice('forex');
    const historicalPrices = generateHistoricalPrices(basePrice, volatility);
    const latestPrice = historicalPrices[historicalPrices.length - 1].close;
    const previousPrice = historicalPrices[historicalPrices.length - 2].close;
    
    assets.push({
      id: `forex_${index}`,
      symbol,
      name: symbol.replace('/', ' to '),
      assetClass: 'forex',
      price: latestPrice,
      previousPrice,
      dailyChange: latestPrice - previousPrice,
      dailyChangePercent: ((latestPrice - previousPrice) / previousPrice) * 100,
      volatility,
      volume: Math.floor(1000000 + Math.random() * 99000000), // 1M - 100M
      historicalPrices
    });
  });
  
  // Generate crypto
  CRYPTO_SYMBOLS.forEach((symbol, index) => {
    const volatility = 2 + Math.random() * 8; // 2% - 10% (higher volatility)
    const basePrice = generateBasePrice('crypto');
    const historicalPrices = generateHistoricalPrices(basePrice, volatility);
    const latestPrice = historicalPrices[historicalPrices.length - 1].close;
    const previousPrice = historicalPrices[historicalPrices.length - 2].close;
    
    assets.push({
      id: `crypto_${index}`,
      symbol,
      name: symbol.split('/')[0],
      assetClass: 'crypto',
      price: latestPrice,
      previousPrice,
      dailyChange: latestPrice - previousPrice,
      dailyChangePercent: ((latestPrice - previousPrice) / previousPrice) * 100,
      volatility,
      volume: Math.floor(10000 + Math.random() * 9990000), // 10K - 10M
      historicalPrices
    });
  });
  
  return assets;
};

// Market event generators
const EVENT_TITLES = {
  economic: [
    'Interest Rate Decision', 
    'GDP Data Release', 
    'Unemployment Report', 
    'Inflation Data', 
    'Trade Balance Figures',
    'Housing Market Data',
    'Consumer Confidence Index'
  ],
  political: [
    'Election Results', 
    'Political Tension', 
    'Trade Agreement', 
    'Regulatory Changes', 
    'Diplomatic Crisis',
    'Government Shutdown',
    'Policy Announcement'
  ],
  company: [
    'Earnings Report', 
    'CEO Resignation', 
    'Product Launch', 
    'Merger Announcement', 
    'Lawsuit Filed',
    'Major Contract Win',
    'Dividend Announcement'
  ],
  'flash-crash': [
    'Algorithm Malfunction', 
    'Liquidity Crisis', 
    'Market Structure Failure', 
    'Trading Halt'
  ],
  crisis: [
    'Banking Crisis', 
    'Market Bubble Burst', 
    'Global Recession', 
    'Financial Market Meltdown',
    'Credit Crunch'
  ]
};

const EVENT_DESCRIPTIONS = {
  economic: [
    'Central bank announces surprising change in interest rates, causing market volatility.',
    'GDP figures show unexpected economic growth, boosting market confidence.',
    'Unemployment reaches a multi-year low, affecting market sentiment positively.',
    'Inflation data comes in higher than expected, causing concern among investors.',
    'Trade deficit widens significantly, putting pressure on the domestic currency.'
  ],
  political: [
    'Surprise election outcome creates uncertainty in financial markets.',
    'International tensions escalate, affecting global trade relationships.',
    'New trade agreement announced between major economies, boosting related sectors.',
    'Regulatory changes target specific industries, causing sector-wide repricing.',
    'Political crisis develops, leading to increased market uncertainty.'
  ],
  company: [
    'Quarterly earnings significantly miss analyst expectations.',
    'Unexpected leadership change announced, causing stock volatility.',
    'Revolutionary new product unveiled, boosting company valuation.',
    'Major companies announce merger plans, reshaping industry dynamics.',
    'Legal challenges emerge for key market player, creating uncertainty.'
  ],
  'flash-crash': [
    'Algorithmic trading systems malfunction, causing rapid price declines.',
    'Sudden liquidity disappears from the market, triggering cascading sell orders.',
    'Trading infrastructure fails temporarily, leading to price anomalies.',
    'Circuit breakers triggered after abnormal price movements.'
  ],
  crisis: [
    'Major financial institution faces insolvency, spreading fear across markets.',
    'Asset bubble collapses, wiping out significant market value.',
    'Economic indicators signal recession, triggering widespread sell-off.',
    'Financial system faces structural crisis, requiring intervention.'
  ]
};

export const generateMarketEvent = (
  assets: Asset[],
  settings: { 
    enableCrises: boolean, 
    enableFlashCrashes: boolean, 
    difficultyLevel: number 
  }
): MarketEvent => {
  // Determine event type based on settings
  let possibleTypes: ('economic' | 'political' | 'company' | 'flash-crash' | 'crisis')[] = 
    ['economic', 'political', 'company'];
  
  if (settings.enableFlashCrashes) possibleTypes.push('flash-crash');
  if (settings.enableCrises) possibleTypes.push('crisis');
  
  // Weighted random selection - more severe events are less likely
  let eventType = possibleTypes[Math.floor(Math.random() * possibleTypes.length)];
  
  // For higher difficulty, increase chance of severe events
  if (settings.difficultyLevel > 3 && Math.random() < 0.2 * (settings.difficultyLevel - 3)) {
    eventType = possibleTypes.filter(t => t === 'flash-crash' || t === 'crisis')[
      Math.floor(Math.random() * (possibleTypes.filter(t => t === 'flash-crash' || t === 'crisis').length))
    ];
  }
  
  // Select random title and description
  const titles = EVENT_TITLES[eventType];
  const descriptions = EVENT_DESCRIPTIONS[eventType];
  const title = titles[Math.floor(Math.random() * titles.length)];
  const description = descriptions[Math.floor(Math.random() * descriptions.length)];
  
  // Determine severity (1-5)
  // Higher difficulty = higher chance of severe events
  const baseSeverity = Math.floor(Math.random() * 3) + 1; // 1-3
  const difficultyBonus = Math.random() < 0.2 * settings.difficultyLevel ? 2 : 0; // +2 based on difficulty
  const severity = Math.min(5, baseSeverity + difficultyBonus) as 1 | 2 | 3 | 4 | 5;
  
  // Select affected assets
  let affectedAssets: string[] = [];
  
  if (eventType === 'economic') {
    // Economic events affect forex and potentially all assets
    if (Math.random() < 0.7) {
      affectedAssets = assets.filter(a => a.assetClass === 'forex').map(a => a.id);
      // Sometimes affects other asset classes too
      if (Math.random() < 0.3) {
        const otherAssets = assets.filter(a => a.assetClass !== 'forex');
        const affectedOthers = otherAssets.filter(() => Math.random() < 0.3);
        affectedAssets = [...affectedAssets, ...affectedOthers.map(a => a.id)];
      }
    } else {
      // Global economic event
      affectedAssets = assets.filter(() => Math.random() < 0.5).map(a => a.id);
    }
  } else if (eventType === 'political') {
    // Political events often affect forex and specific stocks
    affectedAssets = assets
      .filter(a => a.assetClass === 'forex' || (a.assetClass === 'stock' && Math.random() < 0.3))
      .map(a => a.id);
  } else if (eventType === 'company') {
    // Company events affect specific stocks and sometimes related ones
    const stockAssets = assets.filter(a => a.assetClass === 'stock');
    const primaryAffected = stockAssets[Math.floor(Math.random() * stockAssets.length)];
    affectedAssets = [primaryAffected.id];
    // Sometimes affects other stocks too (industry effect)
    if (Math.random() < 0.3) {
      const relatedStocks = stockAssets.filter(a => a.id !== primaryAffected.id && Math.random() < 0.3);
      affectedAssets = [...affectedAssets, ...relatedStocks.map(a => a.id)];
    }
  } else if (eventType === 'flash-crash' || eventType === 'crisis') {
    // These events affect many or all assets
    const affectAllAssets = Math.random() < 0.3 || (eventType === 'crisis' && severity > 3);
    
    if (affectAllAssets) {
      affectedAssets = assets.map(a => a.id);
    } else {
      // Affect a specific asset class entirely
      const targetClass = ['stock', 'forex', 'crypto'][Math.floor(Math.random() * 3)] as AssetClass;
      affectedAssets = assets.filter(a => a.assetClass === targetClass).map(a => a.id);
      
      // Add some random assets from other classes
      const otherAssets = assets.filter(a => a.assetClass !== targetClass);
      const additionalAffected = otherAssets.filter(() => Math.random() < 0.2);
      affectedAssets = [...affectedAssets, ...additionalAffected.map(a => a.id)];
    }
  }
  
  // Impact duration depends on severity and event type
  const baseDuration = 60; // 1 minute in seconds
  const durationMultiplier = {
    'economic': 60, // 1-5 hours
    'political': 30, // 30-150 minutes
    'company': 15, // 15-75 minutes
    'flash-crash': 2, // 2-10 minutes
    'crisis': 120, // 2-10 hours
  }[eventType];
  
  const impactDuration = baseDuration * durationMultiplier * severity;
  
  // Determine impact type and direction
  const impactType = Math.random() < 0.6 ? 'both' : (Math.random() < 0.5 ? 'volatility' : 'trend');
  const impactDirection = Math.random() < 0.4 ? 'negative' : (Math.random() < 0.7 ? 'positive' : 'mixed');
  
  return {
    id: `event_${Date.now()}_${Math.random().toString(36).substring(7)}`,
    type: eventType,
    title,
    description,
    severity,
    affectedAssets,
    impactDuration,
    impactType,
    impactDirection,
    timestamp: Date.now()
  };
};