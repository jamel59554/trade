export type Achievement = {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'trading' | 'risk' | 'strategy' | 'crisis' | 'mastery';
  condition: string;
  progress: number;
  maxProgress: number;
  completed: boolean;
  completedAt?: number;
  reward?: {
    type: 'points' | 'badge' | 'feature';
    value: number | string;
  };
};

export type Challenge = {
  id: string;
  title: string;
  description: string;
  type: 'daily' | 'weekly' | 'special';
  difficulty: 1 | 2 | 3;
  progress: number;
  goal: number;
  reward: number; // points
  expiresAt: number;
  completed: boolean;
};

export type UserProgress = {
  level: number;
  currentXP: number;
  xpToNextLevel: number;
  totalPoints: number;
  rank: string;
  achievements: Achievement[];
  activeChallenges: Challenge[];
  completedChallenges: Challenge[];
  stats: {
    totalTrades: number;
    successfulTrades: number;
    crisisHandled: number;
    maxProfitStreak: number;
    assetsTraded: string[];
    highestProfit: number;
    riskManagementScore: number;
  };
};