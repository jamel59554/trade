export type AssetClass = 'stock' | 'forex' | 'crypto';

export type MarketEvent = {
  id: string;
  type: 'economic' | 'political' | 'company' | 'flash-crash' | 'crisis' | 'central-bank';
  title: string;
  description: string;
  severity: 1 | 2 | 3 | 4 | 5; // 1 = mild, 5 = severe
  affectedAssets: string[];
  impactDuration: number; // in seconds
  impactType: 'volatility' | 'trend' | 'both';
  impactDirection: 'positive' | 'negative' | 'mixed';
  timestamp: number;
};

export type Asset = {
  id: string;
  symbol: string;
  name: string;
  assetClass: AssetClass;
  price: number;
  previousPrice: number;
  dailyChange: number;
  dailyChangePercent: number;
  volatility: number;
  volume: number;
  historicalPrices: HistoricalPrice[];
};

export type HistoricalPrice = {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type TimeFrame = '1m' | '5m' | '15m' | '30m' | '1h' | '4h' | '1d' | '1w';

export type TradePosition = {
  id: string;
  assetId: string;
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  side: 'buy' | 'sell';
  pnl: number;
  pnlPercent: number;
  openTime: number;
  stopLoss?: number;
  takeProfit?: number;
};

export type TradeOrder = {
  id: string;
  assetId: string;
  price: number;
  quantity: number;
  side: 'buy' | 'sell';
  type: 'market' | 'limit' | 'stop' | 'stop-limit';
  status: 'pending' | 'filled' | 'canceled' | 'rejected';
  createdAt: number;
  filledAt?: number;
  stopPrice?: number;
  limitPrice?: number;
  timeInForce?: 'GTC' | 'IOC' | 'FOK';
};

export type SimulationSettings = {
  initialBalance: number;
  volatilityMultiplier: number;
  eventFrequency: number;
  difficultyLevel: 1 | 2 | 3 | 4 | 5;
  enableCrises: boolean;
  enableFlashCrashes: boolean;
  enableCentralBankEvents: boolean;
  adaptiveDifficulty: boolean;
};

export type UserPerformance = {
  balance: number;
  equity: number;
  profitToday: number;
  profitAllTime: number;
  winRate: number;
  tradesCompleted: number;
  averageTradeDuration: number;
  largestWin: number;
  largestLoss: number;
  riskRewardRatio: number;
  sharpeRatio: number;
  maxDrawdown: number;
};