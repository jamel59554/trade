import { create } from 'zustand';
import { Achievement, Challenge, UserProgress } from '../types/gamification';

interface ProgressState {
  progress: UserProgress;
  achievements: Achievement[];
  activeChallenges: Challenge[];
  
  // Actions
  completeAchievement: (id: string) => void;
  updateChallengeProgress: (id: string, progress: number) => void;
  addXP: (amount: number) => void;
  checkLevelUp: () => void;
  generateDailyChallenges: () => void;
}

const calculateXPForLevel = (level: number) => Math.floor(1000 * Math.pow(1.2, level - 1));

const getRankForLevel = (level: number): string => {
  if (level < 5) return 'Novice Trader';
  if (level < 10) return 'Junior Trader';
  if (level < 15) return 'Intermediate Trader';
  if (level < 20) return 'Senior Trader';
  if (level < 25) return 'Expert Trader';
  if (level < 30) return 'Master Trader';
  return 'Trading Legend';
};

export const useProgressStore = create<ProgressState>((set, get) => ({
  progress: {
    level: 1,
    currentXP: 0,
    xpToNextLevel: calculateXPForLevel(1),
    totalPoints: 0,
    rank: 'Novice Trader',
    achievements: [],
    activeChallenges: [],
    completedChallenges: [],
    stats: {
      totalTrades: 0,
      successfulTrades: 0,
      crisisHandled: 0,
      maxProfitStreak: 0,
      assetsTraded: [],
      highestProfit: 0,
      riskManagementScore: 0,
    },
  },
  achievements: [],
  activeChallenges: [],
  
  completeAchievement: (id: string) => {
    set(state => {
      const achievement = state.achievements.find(a => a.id === id && !a.completed);
      if (!achievement) return state;
      
      const updatedAchievements = state.achievements.map(a => 
        a.id === id ? { ...a, completed: true, completedAt: Date.now() } : a
      );
      
      // Add XP reward
      const xpReward = achievement.reward?.type === 'points' ? achievement.reward.value as number : 100;
      
      return {
        achievements: updatedAchievements,
        progress: {
          ...state.progress,
          currentXP: state.progress.currentXP + xpReward,
          achievements: updatedAchievements,
        },
      };
    });
    
    get().checkLevelUp();
  },
  
  updateChallengeProgress: (id: string, progress: number) => {
    set(state => {
      const updatedChallenges = state.activeChallenges.map(challenge => {
        if (challenge.id === id) {
          const completed = progress >= challenge.goal;
          if (completed && !challenge.completed) {
            // Award points for completion
            state.progress.totalPoints += challenge.reward;
          }
          return { ...challenge, progress, completed };
        }
        return challenge;
      });
      
      return {
        activeChallenges: updatedChallenges,
        progress: {
          ...state.progress,
          activeChallenges: updatedChallenges.filter(c => !c.completed),
          completedChallenges: [
            ...state.progress.completedChallenges,
            ...updatedChallenges.filter(c => c.completed),
          ],
        },
      };
    });
  },
  
  addXP: (amount: number) => {
    set(state => ({
      progress: {
        ...state.progress,
        currentXP: state.progress.currentXP + amount,
      },
    }));
    
    get().checkLevelUp();
  },
  
  checkLevelUp: () => {
    set(state => {
      let { level, currentXP, xpToNextLevel } = state.progress;
      
      while (currentXP >= xpToNextLevel) {
        currentXP -= xpToNextLevel;
        level += 1;
        xpToNextLevel = calculateXPForLevel(level);
      }
      
      if (level === state.progress.level) return state;
      
      return {
        progress: {
          ...state.progress,
          level,
          currentXP,
          xpToNextLevel,
          rank: getRankForLevel(level),
        },
      };
    });
  },
  
  generateDailyChallenges: () => {
    const challenges: Challenge[] = [
      {
        id: `daily_${Date.now()}_1`,
        title: 'Profitable Streak',
        description: 'Complete 5 profitable trades in a row',
        type: 'daily',
        difficulty: 2,
        progress: 0,
        goal: 5,
        reward: 100,
        expiresAt: Date.now() + 24 * 60 * 60 * 1000,
        completed: false,
      },
      {
        id: `daily_${Date.now()}_2`,
        title: 'Risk Manager',
        description: 'Successfully use stop-loss orders in 3 trades',
        type: 'daily',
        difficulty: 1,
        progress: 0,
        goal: 3,
        reward: 50,
        expiresAt: Date.now() + 24 * 60 * 60 * 1000,
        completed: false,
      },
      {
        id: `daily_${Date.now()}_3`,
        title: 'Market Explorer',
        description: 'Trade 3 different asset classes',
        type: 'daily',
        difficulty: 2,
        progress: 0,
        goal: 3,
        reward: 75,
        expiresAt: Date.now() + 24 * 60 * 60 * 1000,
        completed: false,
      },
    ];
    
    set(state => ({
      activeChallenges: [
        ...state.activeChallenges.filter(c => c.type !== 'daily'),
        ...challenges,
      ],
    }));
  },
}));