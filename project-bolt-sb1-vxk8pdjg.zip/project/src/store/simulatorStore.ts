import { create } from 'zustand';
import { 
  Asset, 
  MarketEvent, 
  SimulationSettings, 
  TradePosition, 
  TradeOrder,
  UserPerformance
} from '../types/market';
import { generateInitialAssets } from '../utils/marketGenerator';

interface SimulatorState {
  // Market data
  assets: Asset[];
  selectedAsset: Asset | null;
  marketEvents: MarketEvent[];
  
  // User data
  positions: TradePosition[];
  orders: TradeOrder[];
  performance: UserPerformance;
  
  // Simulation settings
  settings: SimulationSettings;
  isSimulationRunning: boolean;
  currentTimeFrame: string;
  
  // Actions
  selectAsset: (assetId: string) => void;
  updateAssetPrice: (assetId: string, newPrice: number) => void;
  addMarketEvent: (event: MarketEvent) => void;
  createOrder: (order: Omit<TradeOrder, 'id' | 'createdAt' | 'status'>) => void;
  cancelOrder: (orderId: string) => void;
  closePosition: (positionId: string) => void;
  startSimulation: () => void;
  pauseSimulation: () => void;
  changeTimeFrame: (timeFrame: string) => void;
  updateSettings: (settings: Partial<SimulationSettings>) => void;
  resetSimulation: () => void;
}

const DEFAULT_SETTINGS: SimulationSettings = {
  initialBalance: 100000,
  volatilityMultiplier: 1,
  eventFrequency: 3, // events per hour
  difficultyLevel: 3,
  enableCrises: true,
  enableFlashCrashes: true,
};

const DEFAULT_PERFORMANCE: UserPerformance = {
  balance: 100000,
  equity: 100000,
  profitToday: 0,
  profitAllTime: 0,
  winRate: 0,
  tradesCompleted: 0,
  averageTradeDuration: 0,
  largestWin: 0,
  largestLoss: 0,
};

const initialAssets = generateInitialAssets();

export const useSimulatorStore = create<SimulatorState>((set, get) => ({
  assets: initialAssets,
  selectedAsset: initialAssets.length > 0 ? initialAssets[0] : null,
  marketEvents: [],
  positions: [],
  orders: [],
  performance: DEFAULT_PERFORMANCE,
  settings: DEFAULT_SETTINGS,
  isSimulationRunning: false,
  currentTimeFrame: '15m',

  selectAsset: (assetId: string) => {
    const asset = get().assets.find(a => a.id === assetId);
    if (asset) {
      set({ selectedAsset: asset });
    }
  },

  updateAssetPrice: (assetId: string, newPrice: number) => {
    set(state => {
      const updatedAssets = state.assets.map(asset => {
        if (asset.id === assetId) {
          const previousPrice = asset.price;
          const dailyChange = newPrice - previousPrice;
          const dailyChangePercent = (dailyChange / previousPrice) * 100;
          
          return {
            ...asset,
            previousPrice,
            price: newPrice,
            dailyChange,
            dailyChangePercent,
            historicalPrices: [
              ...asset.historicalPrices,
              {
                timestamp: Date.now(),
                open: previousPrice,
                high: Math.max(previousPrice, newPrice),
                low: Math.min(previousPrice, newPrice),
                close: newPrice,
                volume: asset.volume * (1 + Math.random() * 0.2 - 0.1) // Random volume fluctuation
              }
            ]
          };
        }
        return asset;
      });

      // Also update the selected asset if it's the one being modified
      let selectedAsset = state.selectedAsset;
      if (selectedAsset && selectedAsset.id === assetId) {
        selectedAsset = updatedAssets.find(a => a.id === assetId) || selectedAsset;
      }

      // Update positions with new price
      const updatedPositions = state.positions.map(position => {
        if (position.assetId === assetId) {
          const asset = updatedAssets.find(a => a.id === assetId);
          if (asset) {
            const newPnl = (asset.price - position.entryPrice) * position.quantity * (position.side === 'buy' ? 1 : -1);
            const newPnlPercent = (newPnl / (position.entryPrice * position.quantity)) * 100;
            
            return {
              ...position,
              currentPrice: asset.price,
              pnl: newPnl,
              pnlPercent: newPnlPercent
            };
          }
        }
        return position;
      });

      // Calculate new equity
      const newEquity = state.performance.balance + updatedPositions.reduce((sum, pos) => sum + pos.pnl, 0);

      return {
        assets: updatedAssets,
        selectedAsset,
        positions: updatedPositions,
        performance: {
          ...state.performance,
          equity: newEquity
        }
      };
    });
  },

  addMarketEvent: (event: MarketEvent) => {
    set(state => ({
      marketEvents: [event, ...state.marketEvents].slice(0, 50) // Keep last 50 events
    }));
  },
  
  createOrder: (orderData) => {
    const order: TradeOrder = {
      id: `order_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      status: 'pending',
      createdAt: Date.now(),
      ...orderData
    };

    // For market orders, execute immediately
    if (order.type === 'market') {
      const { assets, positions, performance } = get();
      const asset = assets.find(a => a.id === order.assetId);
      
      if (asset) {
        // Calculate cost
        const orderCost = order.price * order.quantity;
        
        // Check if enough balance
        if (order.side === 'buy' && orderCost > performance.balance) {
          // Reject order due to insufficient funds
          set(state => ({
            orders: [...state.orders, { ...order, status: 'rejected' }]
          }));
          return;
        }

        // Create or update position
        let updatedPositions = [...positions];
        const existingPosition = positions.find(p => 
          p.assetId === order.assetId && p.side === order.side
        );

        if (existingPosition) {
          // Update existing position
          updatedPositions = updatedPositions.map(position => {
            if (position.id === existingPosition.id) {
              const newQuantity = position.quantity + order.quantity;
              const newEntryPrice = ((position.entryPrice * position.quantity) + 
                (order.price * order.quantity)) / newQuantity;
              
              return {
                ...position,
                quantity: newQuantity,
                entryPrice: newEntryPrice,
                currentPrice: asset.price
              };
            }
            return position;
          });
        } else {
          // Create new position
          const newPosition: TradePosition = {
            id: `pos_${Date.now()}_${Math.random().toString(36).substring(7)}`,
            assetId: order.assetId,
            entryPrice: order.price,
            currentPrice: asset.price,
            quantity: order.quantity,
            side: order.side,
            pnl: 0, // Initialize at 0
            pnlPercent: 0,
            openTime: Date.now()
          };
          updatedPositions.push(newPosition);
        }

        // Update balance
        const newBalance = order.side === 'buy' 
          ? performance.balance - orderCost 
          : performance.balance + orderCost;

        // Update order as filled
        set(state => ({
          positions: updatedPositions,
          orders: [...state.orders, { ...order, status: 'filled', filledAt: Date.now() }],
          performance: {
            ...state.performance,
            balance: newBalance
          }
        }));
      }
    } else {
      // For limit and stop orders, just add to the orders list
      set(state => ({
        orders: [...state.orders, order]
      }));
    }
  },

  cancelOrder: (orderId: string) => {
    set(state => ({
      orders: state.orders.map(order => 
        order.id === orderId ? { ...order, status: 'canceled' } : order
      )
    }));
  },

  closePosition: (positionId: string) => {
    set(state => {
      const position = state.positions.find(p => p.id === positionId);
      if (!position) return state;

      const asset = state.assets.find(a => a.id === position.assetId);
      if (!asset) return state;

      // Calculate final P&L
      const finalPnl = (asset.price - position.entryPrice) * position.quantity * 
        (position.side === 'buy' ? 1 : -1);

      // Update balance and performance stats
      const newBalance = state.performance.balance + finalPnl;
      const newPerformance = {
        ...state.performance,
        balance: newBalance,
        profitAllTime: state.performance.profitAllTime + finalPnl,
        profitToday: state.performance.profitToday + finalPnl,
        tradesCompleted: state.performance.tradesCompleted + 1,
        winRate: finalPnl > 0 
          ? ((state.performance.winRate * state.performance.tradesCompleted) + 1) / (state.performance.tradesCompleted + 1) 
          : (state.performance.winRate * state.performance.tradesCompleted) / (state.performance.tradesCompleted + 1),
        largestWin: finalPnl > 0 ? Math.max(state.performance.largestWin, finalPnl) : state.performance.largestWin,
        largestLoss: finalPnl < 0 ? Math.min(state.performance.largestLoss, finalPnl) : state.performance.largestLoss,
      };

      return {
        positions: state.positions.filter(p => p.id !== positionId),
        performance: newPerformance
      };
    });
  },

  startSimulation: () => {
    set({ isSimulationRunning: true });
    // Actual simulation logic is handled in the SimulationEngine component
  },
  
  pauseSimulation: () => {
    set({ isSimulationRunning: false });
  },
  
  changeTimeFrame: (timeFrame: string) => {
    set({ currentTimeFrame: timeFrame });
  },

  updateSettings: (newSettings) => {
    set(state => ({
      settings: { ...state.settings, ...newSettings }
    }));
  },

  resetSimulation: () => {
    set({
      assets: generateInitialAssets(),
      positions: [],
      orders: [],
      marketEvents: [],
      performance: { ...DEFAULT_PERFORMANCE, balance: get().settings.initialBalance },
      isSimulationRunning: false
    });
  }
}));