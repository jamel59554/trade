import { Trophy, Target, Award, TrendingUp, Shield } from 'lucide-react';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { useProgressStore } from '../../store/progressStore';

export const ProgressDashboard = () => {
  const { progress, activeChallenges } = useProgressStore();
  
  return (
    <div className="space-y-6">
      {/* Level Progress */}
      <Card title="Trading Progress" className="relative overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-2xl font-bold text-white">Level {progress.level}</h3>
            <p className="text-neutral-400">{progress.rank}</p>
          </div>
          <Badge variant="primary" className="text-lg px-4 py-2">
            {progress.totalPoints} pts
          </Badge>
        </div>
        
        <div className="relative pt-1">
          <div className="flex mb-2 items-center justify-between">
            <div>
              <span className="text-xs font-semibold inline-block text-primary-200">
                XP Progress
              </span>
            </div>
            <div className="text-right">
              <span className="text-xs font-semibold inline-block text-primary-200">
                {Math.floor((progress.currentXP / progress.xpToNextLevel) * 100)}%
              </span>
            </div>
          </div>
          <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-primary-900">
            <div
              style={{ width: `${(progress.currentXP / progress.xpToNextLevel) * 100}%` }}
              className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary-500"
            ></div>
          </div>
        </div>
        
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <div className="text-center p-3 bg-background rounded-lg">
            <TrendingUp className="w-6 h-6 text-primary-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{progress.stats.totalTrades}</div>
            <div className="text-xs text-neutral-400">Total Trades</div>
          </div>
          <div className="text-center p-3 bg-background rounded-lg">
            <Trophy className="w-6 h-6 text-success mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {progress.stats.successfulTrades}
            </div>
            <div className="text-xs text-neutral-400">Successful Trades</div>
          </div>
          <div className="text-center p-3 bg-background rounded-lg">
            <Shield className="w-6 h-6 text-warning mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {progress.stats.crisisHandled}
            </div>
            <div className="text-xs text-neutral-400">Crises Handled</div>
          </div>
          <div className="text-center p-3 bg-background rounded-lg">
            <Award className="w-6 h-6 text-accent-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {progress.achievements.filter(a => a.completed).length}
            </div>
            <div className="text-xs text-neutral-400">Achievements</div>
          </div>
        </div>
      </Card>
      
      {/* Active Challenges */}
      <Card title="Daily Challenges" className="h-full">
        <div className="space-y-4">
          {activeChallenges.filter(c => c.type === 'daily').map(challenge => (
            <div
              key={challenge.id}
              className="p-4 bg-background rounded-lg border border-neutral-800"
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-white">{challenge.title}</h4>
                <Badge variant={challenge.completed ? 'success' : 'primary'}>
                  {challenge.completed ? 'Completed' : `${challenge.reward} pts`}
                </Badge>
              </div>
              <p className="text-sm text-neutral-400 mb-3">{challenge.description}</p>
              <div className="relative pt-1">
                <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-neutral-800">
                  <div
                    style={{ width: `${(challenge.progress / challenge.goal) * 100}%` }}
                    className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary-500"
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-neutral-500">
                  <span>{challenge.progress} / {challenge.goal}</span>
                  <span>
                    {Math.floor((challenge.expiresAt - Date.now()) / (1000 * 60 * 60))}h remaining
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
      
      {/* Recent Achievements */}
      <Card title="Recent Achievements" className="h-full">
        <div className="space-y-3">
          {progress.achievements
            .filter(a => a.completed)
            .sort((a, b) => (b.completedAt || 0) - (a.completedAt || 0))
            .slice(0, 5)
            .map(achievement => (
              <div
                key={achievement.id}
                className="flex items-center p-3 bg-background rounded-lg border border-neutral-800"
              >
                <div className="flex-shrink-0 w-10 h-10 bg-primary-500/20 rounded-full flex items-center justify-center mr-3">
                  <Trophy className="w-5 h-5 text-primary-500" />
                </div>
                <div className="flex-grow">
                  <h4 className="font-medium text-white">{achievement.title}</h4>
                  <p className="text-sm text-neutral-400">{achievement.description}</p>
                </div>
                {achievement.reward && (
                  <Badge variant="accent" className="ml-3">
                    +{achievement.reward.value} {achievement.reward.type}
                  </Badge>
                )}
              </div>
            ))}
        </div>
      </Card>
    </div>
  );
};