import { X } from 'lucide-react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { useSimulatorStore } from '../../store/simulatorStore';

export const PositionsTable = () => {
  const { positions, assets, closePosition } = useSimulatorStore();
  
  const getAssetSymbol = (assetId: string) => {
    const asset = assets.find(a => a.id === assetId);
    return asset ? asset.symbol : 'Unknown';
  };
  
  return (
    <Card 
      title="Open Positions" 
      subtitle={positions.length > 0 ? `${positions.length} active position${positions.length > 1 ? 's' : ''}` : undefined}
      className="h-full"
    >
      {positions.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-40 text-neutral-400">
          <p>No open positions</p>
          <p className="text-xs mt-1">Select an asset and place an order to open a position</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-background text-neutral-400 border-b border-neutral-800">
                <th className="px-4 py-2 text-left font-medium">Symbol</th>
                <th className="px-4 py-2 text-right font-medium">Side</th>
                <th className="px-4 py-2 text-right font-medium">Size</th>
                <th className="px-4 py-2 text-right font-medium">Entry</th>
                <th className="px-4 py-2 text-right font-medium">Current</th>
                <th className="px-4 py-2 text-right font-medium">P&L</th>
                <th className="px-4 py-2 text-right font-medium"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800">
              {positions.map(position => (
                <tr key={position.id} className="hover:bg-background transition-colors">
                  <td className="px-4 py-3 text-white">
                    {getAssetSymbol(position.assetId)}
                  </td>
                  <td className={`px-4 py-3 text-right font-medium ${
                    position.side === 'buy' ? 'text-success' : 'text-danger'
                  }`}>
                    {position.side.toUpperCase()}
                  </td>
                  <td className="px-4 py-3 text-right font-mono">
                    {position.quantity}
                  </td>
                  <td className="px-4 py-3 text-right font-mono">
                    ${position.entryPrice.toFixed(2)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono">
                    ${position.currentPrice.toFixed(2)}
                  </td>
                  <td className={`px-4 py-3 text-right font-medium ${
                    position.pnl >= 0 ? 'text-success' : 'text-danger'
                  }`}>
                    ${position.pnl.toFixed(2)} ({position.pnlPercent.toFixed(2)}%)
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => closePosition(position.id)}
                      leftIcon={<X size={14} />}
                    >
                      Close
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
};