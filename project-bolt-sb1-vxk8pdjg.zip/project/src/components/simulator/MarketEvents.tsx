import { format } from 'date-fns';
import { AlertCircle, TrendingUp, TrendingDown } from 'lucide-react';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { useSimulatorStore } from '../../store/simulatorStore';

export const MarketEvents = () => {
  const { marketEvents } = useSimulatorStore();
  
  const getSeverityLabel = (severity: number) => {
    switch (severity) {
      case 1: return { text: 'Low Impact', variant: 'primary' };
      case 2: return { text: 'Moderate', variant: 'secondary' };
      case 3: return { text: 'Significant', variant: 'warning' };
      case 4: return { text: 'High Impact', variant: 'warning' };
      case 5: return { text: 'Severe', variant: 'danger' };
      default: return { text: 'Unknown', variant: 'default' };
    }
  };
  
  const getEventIcon = (type: string) => {
    switch (type) {
      case 'economic': return <TrendingUp size={16} />;
      case 'political': return <AlertCircle size={16} />;
      case 'company': return <TrendingUp size={16} />;
      case 'flash-crash': return <TrendingDown size={16} className="text-danger" />;
      case 'crisis': return <AlertCircle size={16} className="text-danger" />;
      default: return <AlertCircle size={16} />;
    }
  };
  
  if (marketEvents.length === 0) {
    return (
      <Card title="Market Events" className="h-full">
        <div className="flex flex-col items-center justify-center h-40 text-neutral-400">
          <p>No market events yet</p>
          <p className="text-xs mt-1">Events will appear as the simulation progresses</p>
        </div>
      </Card>
    );
  }
  
  return (
    <Card title="Market Events" className="h-full">
      <div className="space-y-3 max-h-[350px] overflow-y-auto">
        {marketEvents.map(event => {
          const severityInfo = getSeverityLabel(event.severity);
          return (
            <div 
              key={event.id} 
              className="p-3 bg-background rounded border border-neutral-800 animate-fade-in"
            >
              <div className="flex items-start">
                <div className="mr-3 mt-0.5">{getEventIcon(event.type)}</div>
                <div className="flex-grow">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-white">{event.title}</h4>
                    <Badge variant={severityInfo.variant as any}>
                      {severityInfo.text}
                    </Badge>
                  </div>
                  <p className="text-sm text-neutral-300 mt-1">{event.description}</p>
                  <div className="flex items-center justify-between mt-2 text-xs text-neutral-400">
                    <span>{format(event.timestamp, 'HH:mm:ss')}</span>
                    <span className="capitalize">{event.type.replace('-', ' ')} Event</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
};