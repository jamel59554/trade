import { useEffect, useRef, useState } from 'react';
import { createChart, ColorType } from 'lightweight-charts';
import { Asset } from '../../types/market';
import { Button } from '../ui/Button';

interface PriceChartProps {
  asset: Asset | null;
  timeframe: string;
}

export const PriceChart = ({ asset, timeframe }: PriceChartProps) => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<any>(null);
  const seriesRef = useRef<any>(null);
  const [priceScale, setPriceScale] = useState<'auto' | 'log'>('auto');

  // Initialize chart
  useEffect(() => {
    if (!chartContainerRef.current) return;

    // Create chart instance
    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: '#0e1117' },
        textColor: '#d1d5db',
      },
      grid: {
        vertLines: { color: '#1a1f2a' },
        horzLines: { color: '#1a1f2a' },
      },
      width: chartContainerRef.current.clientWidth,
      height: 400,
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
        borderColor: '#2b323f',
      },
      rightPriceScale: {
        borderColor: '#2b323f',
        scaleMargins: {
          top: 0.1,
          bottom: 0.1,
        },
      },
      handleScroll: true,
      handleScale: true,
    });

    // Add candlestick series
    const series = chart.addCandlestickSeries({
      upColor: '#22c55e',
      downColor: '#ef4444',
      borderUpColor: '#22c55e',
      borderDownColor: '#ef4444',
      wickUpColor: '#22c55e',
      wickDownColor: '#ef4444',
    });

    chartRef.current = chart;
    seriesRef.current = series;
    
    // On resize
    const handleResize = () => {
      if (chartRef.current && chartContainerRef.current) {
        chartRef.current.applyOptions({
          width: chartContainerRef.current.clientWidth,
        });
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (chartRef.current) {
        chartRef.current.remove();
        chartRef.current = null;
        seriesRef.current = null;
      }
    };
  }, []);

  // Update chart data when asset changes
  useEffect(() => {
    if (!seriesRef.current || !asset) return;
    
    // Format data for lightweight-charts
    const candleData = asset.historicalPrices.map(price => ({
      time: Math.floor(price.timestamp / 1000),
      open: price.open,
      high: price.high,
      low: price.low, 
      close: price.close,
    }));
    
    seriesRef.current.setData(candleData);
    
    // Set chart title
    if (chartRef.current) {
      chartRef.current.applyOptions({
        priceScale: {
          mode: priceScale,
        },
      });
    }
  }, [asset, priceScale]);

  // Toggle price scale between auto and log
  const togglePriceScale = () => {
    setPriceScale(prev => prev === 'auto' ? 'log' : 'auto');
  };

  if (!asset) {
    return (
      <div className="h-[400px] flex items-center justify-center bg-background-light border border-neutral-800 rounded-lg">
        <p className="text-neutral-400">Select an asset to view chart</p>
      </div>
    );
  }

  return (
    <div className="bg-background-light border border-neutral-800 rounded-lg overflow-hidden">
      <div className="p-3 border-b border-neutral-800 flex items-center justify-between">
        <div>
          <h3 className="font-medium text-white">{asset.name} ({asset.symbol})</h3>
          <div className="flex items-center mt-1">
            <span className="text-lg font-mono font-medium text-white">
              ${asset.price.toFixed(asset.assetClass === 'forex' ? 4 : 2)}
            </span>
            <span 
              className={`ml-2 text-sm ${
                asset.dailyChange >= 0 ? 'text-success' : 'text-danger'
              }`}
            >
              {asset.dailyChange >= 0 ? '+' : ''}
              {asset.dailyChangePercent.toFixed(2)}%
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex bg-neutral-800 rounded-md p-0.5">
            {['1m', '5m', '15m', '30m', '1h', '4h', '1d'].map((tf) => (
              <button
                key={tf}
                className={`px-2 py-1 text-xs rounded ${
                  timeframe === tf
                    ? 'bg-primary-500 text-white'
                    : 'text-neutral-400 hover:text-white'
                }`}
                onClick={() => {/* timeframe change would be handled by parent */}}
              >
                {tf}
              </button>
            ))}
          </div>

          <Button
            size="sm"
            variant="outline"
            onClick={togglePriceScale}
            className="text-xs"
          >
            {priceScale === 'auto' ? 'Auto' : 'Log'} Scale
          </Button>
        </div>
      </div>
      <div ref={chartContainerRef} className="w-full h-[400px]" />
    </div>
  );
};