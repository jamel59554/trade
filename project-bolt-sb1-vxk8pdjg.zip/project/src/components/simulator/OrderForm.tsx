import { useState } from 'react';
import { useSimulatorStore } from '../../store/simulatorStore';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';

export const OrderForm = () => {
  const { selectedAsset, createOrder, performance } = useSimulatorStore();
  
  const [quantity, setQuantity] = useState<string>('1');
  const [orderType, setOrderType] = useState<'market' | 'limit' | 'stop'>('market');
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [price, setPrice] = useState<string>('');
  
  // Reset price field when order type changes
  const handleOrderTypeChange = (type: 'market' | 'limit' | 'stop') => {
    setOrderType(type);
    if (type === 'market' && selectedAsset) {
      setPrice(selectedAsset.price.toString());
    } else {
      setPrice('');
    }
  };
  
  // Update price field when selected asset changes
  const handleSideChange = (newSide: 'buy' | 'sell') => {
    setSide(newSide);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedAsset) return;
    
    const orderPrice = orderType === 'market' 
      ? selectedAsset.price
      : parseFloat(price);
      
    const orderQuantity = parseFloat(quantity);
    
    if (isNaN(orderQuantity) || orderQuantity <= 0) return;
    if (orderType !== 'market' && (isNaN(orderPrice) || orderPrice <= 0)) return;
    
    // Check if user has enough balance for buy orders
    if (side === 'buy') {
      const totalCost = orderPrice * orderQuantity;
      if (totalCost > performance.balance) {
        // Could show error message here
        return;
      }
    }
    
    createOrder({
      assetId: selectedAsset.id,
      price: orderPrice,
      quantity: orderQuantity,
      side,
      type: orderType,
    });
    
    // Reset form
    setQuantity('1');
    if (orderType !== 'market') {
      setPrice('');
    }
  };
  
  if (!selectedAsset) {
    return (
      <Card title="New Order" className="h-full">
        <div className="flex items-center justify-center h-40 text-neutral-400">
          <p>Select an asset to place an order</p>
        </div>
      </Card>
    );
  }
  
  const estimatedCost = parseFloat(quantity) * (orderType === 'market' 
    ? selectedAsset.price 
    : (parseFloat(price) || selectedAsset.price));
  
  const isInsufficientFunds = side === 'buy' && estimatedCost > performance.balance;
  
  return (
    <Card title="New Order" subtitle={selectedAsset.symbol} className="h-full">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-neutral-300 mb-1">
            Side
          </label>
          <div className="flex">
            <button
              type="button"
              className={`flex-1 py-2 font-medium ${
                side === 'buy'
                  ? 'bg-success text-white'
                  : 'bg-background border border-neutral-700 text-neutral-300'
              } rounded-l`}
              onClick={() => handleSideChange('buy')}
            >
              Buy
            </button>
            <button
              type="button"
              className={`flex-1 py-2 font-medium ${
                side === 'sell'
                  ? 'bg-danger text-white'
                  : 'bg-background border border-neutral-700 text-neutral-300'
              } rounded-r`}
              onClick={() => handleSideChange('sell')}
            >
              Sell
            </button>
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-neutral-300 mb-1">
            Order Type
          </label>
          <div className="flex">
            <button
              type="button"
              className={`flex-1 py-2 text-sm ${
                orderType === 'market'
                  ? 'bg-primary-500 text-white'
                  : 'bg-background border border-neutral-700 text-neutral-300'
              } rounded-l`}
              onClick={() => handleOrderTypeChange('market')}
            >
              Market
            </button>
            <button
              type="button"
              className={`flex-1 py-2 text-sm ${
                orderType === 'limit'
                  ? 'bg-primary-500 text-white'
                  : 'bg-background border border-neutral-700 text-neutral-300'
              }`}
              onClick={() => handleOrderTypeChange('limit')}
            >
              Limit
            </button>
            <button
              type="button"
              className={`flex-1 py-2 text-sm ${
                orderType === 'stop'
                  ? 'bg-primary-500 text-white'
                  : 'bg-background border border-neutral-700 text-neutral-300'
              } rounded-r`}
              onClick={() => handleOrderTypeChange('stop')}
            >
              Stop
            </button>
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-neutral-300 mb-1">
            Quantity
          </label>
          <input
            type="number"
            min="0.01"
            step="0.01"
            value={quantity}
            onChange={e => setQuantity(e.target.value)}
            className="w-full px-3 py-2 bg-background border border-neutral-700 rounded-md text-neutral-200"
            required
          />
        </div>
        
        {orderType !== 'market' && (
          <div>
            <label className="block text-sm font-medium text-neutral-300 mb-1">
              {orderType === 'limit' ? 'Limit Price' : 'Stop Price'}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <span className="text-neutral-400">$</span>
              </div>
              <input
                type="number"
                min="0.01"
                step="0.01"
                placeholder={selectedAsset.price.toFixed(2)}
                value={price}
                onChange={e => setPrice(e.target.value)}
                className="pl-7 w-full px-3 py-2 bg-background border border-neutral-700 rounded-md text-neutral-200"
                required
              />
            </div>
          </div>
        )}
        
        <div className="flex justify-between text-sm border-t border-neutral-800 pt-3 pb-1">
          <span className="text-neutral-400">Estimated Cost:</span>
          <span className="text-white font-mono">
            ${estimatedCost.toFixed(2)}
          </span>
        </div>
        
        {isInsufficientFunds && (
          <p className="text-danger text-xs text-center">
            Insufficient funds for this order
          </p>
        )}
        
        <Button
          variant={side === 'buy' ? 'success' : 'danger'}
          className="w-full"
          type="submit"
          disabled={isInsufficientFunds}
        >
          {side === 'buy' ? 'Buy' : 'Sell'} {selectedAsset.symbol}
        </Button>
      </form>
    </Card>
  );
};