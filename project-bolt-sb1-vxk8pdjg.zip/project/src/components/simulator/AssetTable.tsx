import { useState } from 'react';
import { Search, ChevronUp, ChevronDown } from 'lucide-react';
import { Asset, AssetClass } from '../../types/market';
import { useSimulatorStore } from '../../store/simulatorStore';
import { Badge } from '../ui/Badge';

type SortField = 'symbol' | 'price' | 'dailyChangePercent' | 'volatility';
type SortDirection = 'asc' | 'desc';

export const AssetTable = () => {
  const { assets, selectAsset, selectedAsset } = useSimulatorStore();
  const [filter, setFilter] = useState('');
  const [assetClassFilter, setAssetClassFilter] = useState<AssetClass | 'all'>('all');
  const [sortField, setSortField] = useState<SortField>('symbol');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  // Filter assets by search term and asset class
  const filteredAssets = assets.filter(asset => {
    const matchesSearch = 
      asset.symbol.toLowerCase().includes(filter.toLowerCase()) || 
      asset.name.toLowerCase().includes(filter.toLowerCase());
    
    const matchesAssetClass = assetClassFilter === 'all' || asset.assetClass === assetClassFilter;
    
    return matchesSearch && matchesAssetClass;
  });

  // Sort filtered assets
  const sortedAssets = [...filteredAssets].sort((a, b) => {
    let aValue = a[sortField];
    let bValue = b[sortField];
    
    // Special case for symbol sorting
    if (sortField === 'symbol') {
      aValue = a.symbol;
      bValue = b.symbol;
    }
    
    if (aValue < bValue) {
      return sortDirection === 'asc' ? -1 : 1;
    }
    if (aValue > bValue) {
      return sortDirection === 'asc' ? 1 : -1;
    }
    return 0;
  });

  // Change sort direction
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? <ChevronUp size={16} /> : <ChevronDown size={16} />;
  };

  return (
    <div className="bg-background-light border border-neutral-800 rounded-lg overflow-hidden">
      <div className="p-3 border-b border-neutral-800">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium text-white">Market Assets</h3>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search size={16} className="text-neutral-400" />
            </div>
            <input
              type="text"
              value={filter}
              onChange={e => setFilter(e.target.value)}
              placeholder="Search assets..."
              className="pl-10 pr-3 py-2 w-full bg-background border border-neutral-700 rounded-md text-neutral-200"
            />
          </div>
          <div className="flex sm:w-auto">
            {(['all', 'stock', 'forex', 'crypto'] as const).map(type => (
              <button
                key={type}
                className={`px-3 py-2 text-xs font-medium ${
                  assetClassFilter === type
                    ? 'bg-primary-500 text-white'
                    : 'bg-neutral-800 text-neutral-300'
                } ${type !== 'all' ? 'rounded-none' : 'rounded-l-md'} ${
                  type === 'crypto' ? 'rounded-r-md' : ''
                }`}
                onClick={() => setAssetClassFilter(type)}
              >
                {type === 'all' ? 'All' : type.charAt(0).toUpperCase() + type.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-background text-neutral-400 border-b border-neutral-800">
              <th className="px-4 py-3 text-left font-medium">
                <button 
                  onClick={() => handleSort('symbol')}
                  className="flex items-center space-x-1"
                >
                  <span>Symbol</span>
                  {renderSortIcon('symbol')}
                </button>
              </th>
              <th className="px-4 py-3 text-right font-medium">
                <button 
                  onClick={() => handleSort('price')}
                  className="flex items-center justify-end space-x-1"
                >
                  <span>Price</span>
                  {renderSortIcon('price')}
                </button>
              </th>
              <th className="px-4 py-3 text-right font-medium">
                <button 
                  onClick={() => handleSort('dailyChangePercent')}
                  className="flex items-center justify-end space-x-1"
                >
                  <span>Change</span>
                  {renderSortIcon('dailyChangePercent')}
                </button>
              </th>
              <th className="px-4 py-3 text-right font-medium">
                <button 
                  onClick={() => handleSort('volatility')}
                  className="flex items-center justify-end space-x-1"
                >
                  <span>Volatility</span>
                  {renderSortIcon('volatility')}
                </button>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-800">
            {sortedAssets.map(asset => (
              <tr 
                key={asset.id} 
                className={`hover:bg-background cursor-pointer transition-colors ${
                  selectedAsset?.id === asset.id ? 'bg-background' : ''
                }`}
                onClick={() => selectAsset(asset.id)}
              >
                <td className="px-4 py-3">
                  <div>
                    <div className="flex items-center">
                      <span className="font-medium text-white">{asset.symbol}</span>
                      <Badge 
                        variant={
                          asset.assetClass === 'stock' ? 'primary' : 
                          asset.assetClass === 'forex' ? 'secondary' : 
                          'accent'
                        } 
                        className="ml-2"
                      >
                        {asset.assetClass.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="text-xs text-neutral-400 mt-0.5">{asset.name}</div>
                  </div>
                </td>
                <td className="px-4 py-3 text-right font-mono">
                  ${asset.price.toFixed(asset.assetClass === 'forex' ? 4 : 2)}
                </td>
                <td className={`px-4 py-3 text-right ${
                  asset.dailyChangePercent >= 0 ? 'text-success' : 'text-danger'
                }`}>
                  {asset.dailyChangePercent >= 0 ? '+' : ''}
                  {asset.dailyChangePercent.toFixed(2)}%
                </td>
                <td className="px-4 py-3 text-right">
                  {asset.volatility.toFixed(1)}%
                </td>
              </tr>
            ))}
            
            {filteredAssets.length === 0 && (
              <tr>
                <td colSpan={4} className="px-4 py-6 text-center text-neutral-400">
                  No assets found matching your filters
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};