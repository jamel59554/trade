import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { Button } from '../ui/Button';
import { SimulationSettings } from '../../types/market';
import { useSimulatorStore } from '../../store/simulatorStore';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal = ({ isOpen, onClose }: SettingsModalProps) => {
  const { settings, updateSettings, resetSimulation } = useSimulatorStore();
  const [localSettings, setLocalSettings] = useState<SimulationSettings>(settings);
  
  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);
  
  if (!isOpen) return null;
  
  const handleSave = () => {
    updateSettings(localSettings);
    resetSimulation();
    onClose();
  };
  
  const handleCancel = () => {
    setLocalSettings(settings);
    onClose();
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-background-light rounded-lg w-full max-w-md p-6 animate-slide-up">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-white">Simulation Settings</h2>
          <button onClick={handleCancel} className="text-neutral-400 hover:text-white">
            <X size={20} />
          </button>
        </div>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-neutral-300 mb-2">
              Initial Balance
            </label>
            <input
              type="number"
              min="1000"
              max="1000000"
              value={localSettings.initialBalance}
              onChange={e => setLocalSettings({
                ...localSettings,
                initialBalance: parseInt(e.target.value)
              })}
              className="w-full px-3 py-2 bg-background border border-neutral-700 rounded-md text-neutral-200"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-300 mb-2">
              Market Volatility
            </label>
            <input
              type="range"
              min="0.1"
              max="3"
              step="0.1"
              value={localSettings.volatilityMultiplier}
              onChange={e => setLocalSettings({
                ...localSettings,
                volatilityMultiplier: parseFloat(e.target.value)
              })}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-neutral-400 mt-1">
              <span>Low</span>
              <span>Normal</span>
              <span>High</span>
            </div>
            <p className="text-center text-sm text-neutral-300 mt-1">
              {localSettings.volatilityMultiplier.toFixed(1)}x
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-300 mb-2">
              Event Frequency
            </label>
            <input
              type="range"
              min="1"
              max="12"
              step="1"
              value={localSettings.eventFrequency}
              onChange={e => setLocalSettings({
                ...localSettings,
                eventFrequency: parseInt(e.target.value)
              })}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-neutral-400 mt-1">
              <span>Rare</span>
              <span>Normal</span>
              <span>Frequent</span>
            </div>
            <p className="text-center text-sm text-neutral-300 mt-1">
              {localSettings.eventFrequency} events/hour
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-300 mb-2">
              Difficulty Level
            </label>
            <div className="flex justify-between space-x-2">
              {[1, 2, 3, 4, 5].map(level => (
                <button
                  key={level}
                  onClick={() => setLocalSettings({
                    ...localSettings,
                    difficultyLevel: level as 1 | 2 | 3 | 4 | 5
                  })}
                  className={`flex-1 py-2 rounded ${
                    localSettings.difficultyLevel === level
                      ? 'bg-primary-500 text-white'
                      : 'bg-background border border-neutral-700 text-neutral-300'
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
            <div className="flex justify-between text-xs text-neutral-400 mt-1">
              <span>Easy</span>
              <span></span>
              <span>Normal</span>
              <span></span>
              <span>Hard</span>
            </div>
          </div>
          
          <div className="flex flex-col space-y-3">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={localSettings.enableCrises}
                onChange={e => setLocalSettings({
                  ...localSettings,
                  enableCrises: e.target.checked
                })}
                className="mr-2"
              />
              <span className="text-sm text-neutral-300">Enable Market Crises</span>
            </label>
            
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={localSettings.enableFlashCrashes}
                onChange={e => setLocalSettings({
                  ...localSettings,
                  enableFlashCrashes: e.target.checked
                })}
                className="mr-2"
              />
              <span className="text-sm text-neutral-300">Enable Flash Crashes</span>
            </label>
            
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={localSettings.enableCentralBankEvents}
                onChange={e => setLocalSettings({
                  ...localSettings,
                  enableCentralBankEvents: e.target.checked
                })}
                className="mr-2"
              />
              <span className="text-sm text-neutral-300">Enable Central Bank Events</span>
            </label>
            
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={localSettings.adaptiveDifficulty}
                onChange={e => setLocalSettings({
                  ...localSettings,
                  adaptiveDifficulty: e.target.checked
                })}
                className="mr-2"
              />
              <span className="text-sm text-neutral-300">Enable Adaptive Difficulty</span>
            </label>
          </div>
        </div>
        
        <div className="flex justify-end space-x-3 mt-6">
          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSave}>
            Save & Reset Simulation
          </Button>
        </div>
      </div>
    </div>
  );
};