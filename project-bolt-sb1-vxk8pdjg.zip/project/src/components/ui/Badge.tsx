import { cn } from '../../utils/cn';

interface BadgeProps {
  variant?: 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'danger';
  children: React.ReactNode;
  className?: string;
}

export const Badge = ({ 
  variant = 'default', 
  children, 
  className 
}: BadgeProps) => {
  const variants = {
    default: 'bg-neutral-700 text-neutral-100',
    primary: 'bg-primary-500/20 text-primary-300',
    secondary: 'bg-secondary-500/20 text-secondary-300',
    success: 'bg-success/20 text-success-light',
    warning: 'bg-warning/20 text-warning-light',
    danger: 'bg-danger/20 text-danger-light'
  };

  return (
    <span 
      className={cn(
        'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
        variants[variant],
        className
      )}
    >
      {children}
    </span>
  );
};