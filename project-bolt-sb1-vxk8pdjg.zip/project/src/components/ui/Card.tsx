import { ReactNode } from 'react';
import { cn } from '../../utils/cn';

interface CardProps {
  children: ReactNode;
  className?: string;
  title?: string;
  subtitle?: string;
  contentClassName?: string;
  headerClassName?: string;
  headerRightContent?: ReactNode;
  footer?: ReactNode;
}

export const Card = ({ 
  children, 
  className,
  title,
  subtitle,
  contentClassName, 
  headerClassName,
  headerRightContent,
  footer
}: CardProps) => {
  const hasHeader = title || subtitle || headerRightContent;
  
  return (
    <div 
      className={cn(
        'bg-background-light rounded-lg border border-neutral-800 shadow-sm overflow-hidden',
        className
      )}
    >
      {hasHeader && (
        <div className={cn(
          'flex items-center justify-between p-4 border-b border-neutral-800',
          headerClassName
        )}>
          <div>
            {title && <h3 className="font-medium text-neutral-100">{title}</h3>}
            {subtitle && <p className="text-sm text-neutral-400 mt-0.5">{subtitle}</p>}
          </div>
          {headerRightContent && (
            <div>{headerRightContent}</div>
          )}
        </div>
      )}
      
      <div className={cn('p-4', contentClassName)}>
        {children}
      </div>
      
      {footer && (
        <div className="p-4 border-t border-neutral-800">
          {footer}
        </div>
      )}
    </div>
  );
};