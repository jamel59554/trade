import { useEffect, useState } from 'react';
import { SimulationEngine } from '../../utils/simulationEngine';
import { useSimulatorStore } from '../../store/simulatorStore';
import { Header } from './Header';
import { AssetTable } from '../simulator/AssetTable';
import { PriceChart } from '../simulator/PriceChart';
import { OrderForm } from '../simulator/OrderForm';
import { PositionsTable } from '../simulator/PositionsTable';
import { MarketEvents } from '../simulator/MarketEvents';
import { ProgressDashboard } from '../gamification/ProgressDashboard';

export const Dashboard = () => {
  const { 
    assets, 
    settings,
    isSimulationRunning,
    selectedAsset,
    currentTimeFrame,
    updateAssetPrice,
    addMarketEvent,
  } = useSimulatorStore();
  
  const [simulationEngine, setSimulationEngine] = useState<SimulationEngine | null>(null);
  const [showProgress, setShowProgress] = useState(false);
  
  // Initialize simulation engine
  useEffect(() => {
    const engine = new SimulationEngine(
      assets,
      settings,
      currentTimeFrame,
      updateAssetPrice,
      addMarketEvent
    );
    
    setSimulationEngine(engine);
    
    return () => {
      engine.destroy();
    };
  }, []);
  
  // Update simulation engine when assets or settings change
  useEffect(() => {
    if (simulationEngine) {
      simulationEngine.updateAssets(assets);
      simulationEngine.updateSettings(settings);
      simulationEngine.setTimeframe(currentTimeFrame);
    }
  }, [assets, settings, currentTimeFrame]);
  
  // Start/pause simulation based on state
  useEffect(() => {
    if (!simulationEngine) return;
    
    if (isSimulationRunning) {
      simulationEngine.start();
    } else {
      simulationEngine.pause();
    }
  }, [isSimulationRunning, simulationEngine]);

  return (
    <div className="min-h-screen bg-background text-neutral-200">
      <Header onToggleProgress={() => setShowProgress(!showProgress)} />
      
      <main className="pt-20 pb-8 px-4 max-w-[1920px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {showProgress ? (
            <div className="lg:col-span-3">
              <ProgressDashboard />
            </div>
          ) : (
            <>
              <div className="lg:col-span-2 space-y-6">
                <PriceChart 
                  asset={selectedAsset} 
                  timeframe={currentTimeFrame}
                />
                <PositionsTable />
              </div>
              
              <div className="space-y-6">
                <OrderForm />
                <MarketEvents />
              </div>
            </>
          )}
        </div>
        
        <div className="mt-6">
          <AssetTable />
        </div>
      </main>
    </div>
  );
};