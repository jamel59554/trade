import { useState } from 'react';
import { Play, Pause, Settings, HelpCircle, Trophy } from 'lucide-react';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { useSimulatorStore } from '../../store/simulatorStore';
import { useProgressStore } from '../../store/progressStore';
import { SettingsModal } from '../simulator/SettingsModal';

interface HeaderProps {
  onToggleProgress: () => void;
}

export const Header = ({ onToggleProgress }: HeaderProps) => {
  const { 
    isSimulationRunning, 
    startSimulation, 
    pauseSimulation,
    settings,
    performance
  } = useSimulatorStore();
  
  const { progress } = useProgressStore();
  const [settingsOpen, setSettingsOpen] = useState(false);
  
  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-background border-b border-neutral-800 z-10">
      <div className="px-4 h-full max-w-[1920px] mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-1">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-md bg-gradient-to-tr from-primary-600 to-primary-400 flex items-center justify-center mr-2">
              <span className="text-white font-bold">TS</span>
            </div>
            <h1 className="text-lg font-bold text-white">TradeSim Pro</h1>
          </div>
          
          <Badge 
            variant="primary" 
            className="ml-3"
          >
            {isSimulationRunning ? 'LIVE' : 'PAUSED'}
          </Badge>
          
          <div className="ml-4 flex items-center space-x-2">
            <Badge variant="secondary">Level {progress.level}</Badge>
            <Badge variant="accent">{progress.rank}</Badge>
          </div>
        </div>
        
        <div className="hidden md:flex items-center space-x-8">
          <div className="flex items-center space-x-6">
            <div>
              <p className="text-xs text-neutral-400">Balance</p>
              <p className="text-sm font-mono text-white">
                ${performance.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
            <div>
              <p className="text-xs text-neutral-400">Equity</p>
              <p className="text-sm font-mono text-white">
                ${performance.equity.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
            <div>
              <p className="text-xs text-neutral-400">Daily P/L</p>
              <p className={`text-sm font-mono ${performance.profitToday >= 0 ? 'text-success' : 'text-danger'}`}>
                ${Math.abs(performance.profitToday).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                {performance.profitToday >= 0 ? ' ↑' : ' ↓'}
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="outline" 
            size="sm"
            onClick={onToggleProgress}
            leftIcon={<Trophy size={16} />}
          >
            Progress
          </Button>
          
          <Button
            variant="outline" 
            size="sm"
            leftIcon={<HelpCircle size={16} />}
          >
            Help
          </Button>
          
          <Button
            variant="outline" 
            size="sm"
            onClick={() => setSettingsOpen(true)}
            leftIcon={<Settings size={16} />}
          >
            Settings
          </Button>
          
          {isSimulationRunning ? (
            <Button
              variant="primary" 
              size="sm"
              onClick={pauseSimulation}
              leftIcon={<Pause size={16} />}
            >
              Pause
            </Button>
          ) : (
            <Button
              variant="primary" 
              size="sm"
              onClick={startSimulation}
              leftIcon={<Play size={16} />}
            >
              Start
            </Button>
          )}
        </div>
      </div>
      
      <SettingsModal 
        isOpen={settingsOpen} 
        onClose={() => setSettingsOpen(false)} 
      />
    </header>
  );
};